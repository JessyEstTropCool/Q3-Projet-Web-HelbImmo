from django.contrib import admin
from .models import Profile, Criteria, Notification

admin.site.register(Profile)
admin.site.register(Criteria)
admin.site.register(Notification)